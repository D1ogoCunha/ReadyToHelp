namespace readytohelpapi.Occurrence.Models;

/// <summary>
/// Defines the occurrence statuses.   
/// </summary>
public enum PriorityLevel
{
    LOW,
    MEDIUM,
    HIGH
}